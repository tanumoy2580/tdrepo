#!/usr/bin/python3
print("content-type: text/html \n")

print('<head><title>RHEL8 CGI FACILITY</title></head><body bgcolor="#da70fa"></body>')
import subprocess as sr
import cgi
import socket
import os

hn=socket.gethostname()
ip=socket.gethostbyname(hn)
inp=cgi.FieldStorage()
in1=inp.getvalue("in1")
in2=inp.getvalue("in2")
in3=inp.getvalue("in3")

#Shutdown the OS
if (('shutdown'in in1) or ('off'in in1)):
    print('<font face="Agency FB" size="15" color="#094db3"><center>The Server Is Shutting Down</center></font>')
    tmp=sr.getstatusoutput("sudo shutdown now")


#Fetch my IP Address
elif 'ip'in in1:
    print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    print('<hr><br>')
    print('****************************************************************************************')
    print('RESULT :-<br>')
    print('------------------<br>')
    print(ip)
    print('<br>')
    print('****************************************************************************************')

#Ping a server
elif ('ping'in in1):
    tmp=sr.getstatusoutput("ping -c 4 {}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br><br>\n\n\n')
        print('****************************************************************************************')
        print('Your Required Output is Just Below :-')
        print('-----------------------\n')
        print(tmp[1])
        print('****************************************************************************************')


#Calender of a month
elif ((('cal'in in1) or ('calender'in in1)) and ('month'in in1)):
    tmp=sr.getstatusoutput("cal {0} {1}".format(in2,in3))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br><br>\n\n\n')
        print('****************************************************************************************')
        print('Your Required Output is Just Below :-')
        print('-----------------------\n')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Calender of a full year
elif ((('cal'in in1) or ('calender'in in1)) and ('year'in in1)):
    tmp=sr.getstatusoutput("cal {0}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br><br>\n\n\n')
        print('****************************************************************************************')
        print('Your Required Output is Just Below :-')
        print('-----------------------\n')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Current date
elif ('date'in in1):
    tmp=sr.getstatusoutput("date +%d/%m/%Y")
    if tmp[0] == 0:
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('RESULT :-<br>')
        print('------------------<br>')
        print(tmp[1])
        print('<br>')
        print('****************************************************************************************')


#Current time
elif ('time'in in1):
    tmp=sr.getstatusoutput("date +%I:%M:%S")
    if tmp[0] == 0:
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('RESULT :-<br>')
        print('------------------<br>')
        print(tmp[1])
        print('<br>')
        print('****************************************************************************************')



#Create a folder
elif ((('create'in in1) or ('make'in in1)) and ('folder'in in1)):
    tmp=sr.getstatusoutput("sudo mkdir {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip)) 


#Create a file
elif ((('create'in in1) or ('make'in in1)) and (('file'in in1) or ('document'in in1))):
    tmp=sr.getstatusoutput("sudo touch {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip)) 
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Delete a file or folder
elif ((('remove'in in1) or ('delete'in in1)) and (('folder'in in1) or ('file'in in1))):
    tmp=sr.getstatusoutput("sudo rm -r {} --force".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


# Create user
elif ((('create'in in1) or ('add'in in1)) and (('user'in in1) or ('account'in in1))):
    tmp=sr.getstatusoutput("sudo useradd {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


# Remove user
elif ((('delete'in in1) or ('remove'in in1)) and (('user'in in1) or ('account'in in1))):
    tmp=sr.getstatusoutput("sudo userdel -r {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Read File
elif ((('read'in in1) or ('scan'in in1)) and (('file-contents'in in1) or ('file'in in1))):
    tmp=sr.getstatusoutput("sudo cat {}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br><br>\n\n\n')
        print('****************************************************************************************')
        print('Below Is Your Output :-')
        print('------------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#List the contents in a directory
elif ((('list'in in1) or ('contents'in in1)) and (('location'in in1) or ('directory'in in1))):
    tmp=sr.getstatusoutput("sudo ls -l -h {}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br><br>\n\n\n')
        print('****************************************************************************************')
        print('Below Is Your Output :-')
        print('------------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Rename a file or folder
elif ((('rename'in in1) or ('change'in in1)) and (('filename'in in1) or ('file'in in1) or ('foldername'in in1) or ('folder'in in1))):
    tmp=sr.getstatusoutput("sudo mv {0} {1}".format(in2,in3))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Move a file or folder
elif (('move'in in1) and (('file'in in1) or ('folder'in in1))):
    tmp=sr.getstatusoutput("sudo mv {0} {1}".format(in2,in3))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Copy a file or folder
elif (('copy'in in1) and (('file'in in1) or ('folder'in in1))):
    tmp=sr.getstatusoutput("sudo cp -r {0} {1}".format(in2,in3))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Check whether a software is installed
elif (('check'in in1) and (('software'in in1) or ('installed'in in1))):
    tmp=sr.getstatusoutput("sudo rpm -q {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>This package is already installed<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>This package is not installed<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Uninstall software
elif ((('remove'in in1) or ('un'in in1)) and (('install'in in1) or ('software'in in1) or ('package'in in1))):
    tmp=sr.getstatusoutput("sudo dnf remove {} -y".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#List of all installed packages
elif ((('list' in b) or ('all' in b)) and (('installed' in b) or ('available' in b)) and (('package' in b) or ('software' in b))):
    tmp=sr.getstatusoutput("sudo rpm -q -a")
    if tmp[0] == 0:
        print("Go to view page source or simply press 'Ctrl+u' to see the output <br><br><br>")
        print('<a href="http://{}/c.html"><font color=white>click here to go back to home page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('========================================================================================')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('========================================================================================')
    else:
        print('========================================================================================')
        print('<br>Unsucessful<br>')
        print('----------------<br>')
        print(tmp[1])
        print('========================================================================================')
        print('<a href="http://{}/c.html"><font color=white>click here to go back to home page</font></a><br><br>'.format(ip))


#Install software
elif ((('download'in in1) or ('install'in in1)) and (('software'in in1) or ('package'in in1))):
    tmp=sr.getstatusoutput("sudo dnf install {} -y".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Launch a docker container
elif (('docker'in in1) and (('run'in in1) or ('launch'in in1))):
    tmp=sr.getstatusoutput("sudo docker run -dit --name {} {}".format(in2,in3))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Stop a running docker container
elif (('docker'in in1) and (('stop'in in1) or ('terminate'in in1))):
    tmp=sr.getstatusoutput("sudo docker stop {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Retart a service
elif (('restart'in in1) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl restart {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Start a service
elif (('start'in in1) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl start {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Stop a service
elif (('stop'in in1) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl stop {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Enable a service
elif (('enable'in in1) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl enable {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Disable a service
elif (('disable'in in1) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl disable {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>TASK ACCOMPLISHED<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Check status of a service
elif ((('status'in in1) or ('check'in in1)) and ('service'in in1)):
    tmp=sr.getstatusoutput("sudo systemctl status {}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Check running ports and their programs
elif ((('running'in in1) or ('used'in in1)) and ('ports'in in1)):
    tmp=sr.getstatusoutput("sudo netstat -tnlp")
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Currently running processes
elif (('running'in in1) and (('program'in in1) or ('process'in in1))):
    tmp=sr.getstatusoutput("sudo ps -aux")
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Check all network card details
elif (('network'in in1) and (('adapter'in in1) or ('card'in in1))):
    tmp=sr.getstatusoutput("sudo ifconfig")
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Fetch the source code location of a program
elif (('location'in in1) and ('source'in in1)):
    tmp=sr.getstatusoutput("which {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('RESULT :-<br>')
        print('------------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<br><br><a href="http://{}/input.html"><font color=white>click here to go back to home page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#View manual of any program or service
elif (('manual'in in1) or ('document'in in1) or ('draft'in in1)):
    tmp=sr.getstatusoutput("man {}".format(in2))
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#List of all OS commands or programs
elif ((('list'in in1) or ('all'in in1)) and (('command'in in1) or ('program'in in1))):
    tmp=sr.getstatusoutput("sudo ls /usr/bin/  ")
    if tmp[0] == 0:
        print("To View Proper Output or Result, Open 'view page source' or click on 'Ctrl+u' <br><br><br>")
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
        print('<hr><br>')
        print('****************************************************************************************')
        print('OUTPUT :-')
        print('------------------')
        print(tmp[1])
        print('****************************************************************************************')
    else:
        print('****************************************************************************************')
        print('<br>TASK FAILED<br>')
        print('----------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Check if a spcific file is present in a specific directory
elif (('check'in in1) and ('file'in in1)):
    tmp=sr.getstatusoutput("sudo ls -l {}".format(in2))
    if tmp[0] == 0:
        print('****************************************************************************************')
        print('<br>The file is present<br>')
        print('----------------------------<br>')
        print(tmp[1])
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))
    else:
        print('****************************************************************************************')
        print('<br>The file is not present<br>')
        print('****************************************************************************************')
        print('<a href="http://{}/input.html"><font color=white>Click For Home Page</font></a><br><br>'.format(ip))


#Restart the OS
elif (('restart'in in1) or ('reboot'in in1)):
    print('<font face="Algerian" size="15" color="#094db3"><center>The Server Is Rebooting</center></font>')
    tmp=sr.getstatusoutput("sudo reboot now")


else:
    print("<font size='15'><b> [>>   Unable to recognize your input. Please try again   <<] </b></font><hr><br><br>")
    print('<a href="http://192.168.30.138/input.html"><font color=white>click here to go back to home page</font></a><br><br> \n\n\n')
